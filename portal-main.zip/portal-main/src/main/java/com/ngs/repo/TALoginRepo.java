package com.ngs.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ngs.model.TALogin;

public interface TALoginRepo extends JpaRepository<TALogin,Long> {

}
